



Mass Looker ,it’s a console-based script created for massvoting (mass poll voting) and masslooking stories

# Features
 Author credits : nthanfp
 Modified by @mohsanjid Follow on Instagram www.instagram.com/mohsanjid/ and
 Subscribe Youtube Channel for more videos www.youtube.com/c/PhotoLooz

  - Views Stories
  - Question Answer
  - Poll Voting
  - Emoji Slider
  
# Uses 
   - Unlimited real followers
   - Unlimited real likes
   - Increasing profile visits
   - Incredible reach
   
# Installation

MassLooker requires [PHP](https://www.php.net/) 5.6 to run.

```sh
Follow These Steps for Installation
$pkg install php
$pkg install git
$pkg install mc
$ git clone https://github.com/sanjidtk/masslooker
$ cd masslooker
$ php login.php
$ php run.php
```

